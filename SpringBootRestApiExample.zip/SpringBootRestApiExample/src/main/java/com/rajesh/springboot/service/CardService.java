package com.rajesh.springboot.service;



public interface CardService {
	 public String generate(String bin, int length);
  
}
